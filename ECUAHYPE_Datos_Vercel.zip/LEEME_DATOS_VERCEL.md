# ECUAHYPE: datos reales en Neon y Vercel

## 1. Código en GitHub
Extrae este ZIP. Sube los archivos y carpetas extraídos a la raíz de lopezok12/ECUAHYPE: package.json, package-lock.json, app, lib, scripts, db, public, etc. Subir solamente el ZIP no permite a Vercel compilar ni actualizar el proyecto. No subas .env, data ni node_modules.

## 2. Carga en Neon desde tu computador
Abre la carpeta extraída en Visual Studio Code y una terminal. Usa Node.js 20.9 o posterior. Ejecuta:

```powershell
npm ci
Copy-Item .env.example .env
```

Edita el archivo .env (no escribas estas asignaciones sueltas en PowerShell):

```dotenv
DATABASE_URL=TU_CONEXION_DE_NEON_CON_SSL
FUENTES_REVISADAS=true
CSV_DELIMITER=,
CSV_DECIMAL=.
CSV_ENCODING=utf8
```

La conexión se obtiene en Neon → Connect. Mantén la contraseña privada y usa la misma base en Vercel.

Luego:

```powershell
npm run datos:cargar
```

El comando descarga unos 430 MB de datos oficiales; puede tardar varios minutos. Detecta el último ejercicio cerrado disponible, valida los CSV, crea las tablas y carga compañías, balances de los dos últimos años y actividades. Cada importación es transaccional y puede repetirse: actualiza registros existentes sin duplicarlos. Si una etapa falla, se detiene; las etapas anteriores completadas se conservan. Revisa los conteos y registros omitidos en la terminal.

## 3. Conexión en Vercel
En el proyecto que sirve ecuahypedisenomoderno.vercel.app, abre Settings → Environment Variables. Configura DATABASE_URL con la misma conexión de Neon para Production (y Preview si lo necesitas). Añade SITE_URL=https://ecuahypedisenomoderno.vercel.app. Guarda y haz Redeploy para aplicar los cambios.

Usa framework Next.js, comando de compilación npm run build y directorio raíz vacío si subiste el contenido extraído a la raíz. No uses cf-build ni Wrangler en Vercel.

## 4. Comprobar el contenido
En Neon SQL Editor:

```sql
SELECT count(*) AS empresas FROM empresas;
SELECT anio, count(*) AS balances, count(ingresos) AS con_ingresos
FROM balances GROUP BY anio ORDER BY anio DESC;
SELECT e.nombre, b.anio, b.ingresos
FROM balances b JOIN empresas e USING(ruc)
WHERE b.anio=(SELECT max(anio) FROM balances) AND b.ingresos IS NOT NULL
ORDER BY b.ingresos DESC LIMIT 10;
```

El ranking de la portada es calculado por ECUAHYPE según ingresos totales; no equivale necesariamente a la posición general oficial de SUPERCIAS. Las caídas comparan únicamente empresas con ambos años disponibles. Datos faltantes no equivalen a cero. La fuente es https://appscvsmovil.supercias.gob.ec/ranking/reporte.html.

El CSV de compañías no contiene fecha de constitución ni cantón: "Empresas nuevas" y filtros de ciudad no se completarán con esta descarga. No se inventan fechas. Noticias requiere una carga separada y no se activó en este paquete. No se ha ejecutado la importación sobre tu Neon ni publicado este cambio.
