// Punto de entrada del Worker: Next.js (OpenNext) + tareas programadas (Cron Triggers).
import openNext from "./.open-next/worker.js";

// Reexporta las clases de Durable Objects que OpenNext necesita.
export * from "./.open-next/worker.js";

// Cada expresión cron de wrangler.jsonc apunta a una ruta protegida por CRON_SECRET.
const TAREAS = {
  "*/30 * * * *": "/api/cron/noticias",
  "0 8 * * *": "/api/cron/limpiar",
};

export default {
  fetch: openNext.fetch,

  async scheduled(event, env, ctx) {
    const ruta = TAREAS[event.cron];
    if (!ruta) return;
    if (!env.CRON_SECRET) {
      console.error("CRON_SECRET no configurado: se omite", ruta);
      return;
    }
    const base = (env.SITE_URL || "https://ecuahype.invalid").replace(/\/$/, "");
    const peticion = new Request(base + ruta, { headers: { authorization: `Bearer ${env.CRON_SECRET}` } });
    ctx.waitUntil(
      openNext.fetch(peticion, env, ctx).then(async (r) => {
        if (!r.ok) console.error("Cron", ruta, "respondió", r.status, await r.text());
      })
    );
  },
};
