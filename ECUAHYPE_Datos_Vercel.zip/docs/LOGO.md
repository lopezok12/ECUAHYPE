# Logo ECUAHYPE

Logo original incorporado en public/logo-ecuahype.png, mostrado en el encabezado con proporciones conservadas y enlace a inicio. Ventana CSS oculta los márgenes transparentes; el PNG no se modifica. El título del sitio identifica ECUAHYPE.

