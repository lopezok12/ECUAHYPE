# Diseño ECUAHYPE

Paleta naranja/negro/blanco inspirada en el logo. Portada con buscador, bloque editorial oscuro, tarjetas de rankings, franja informativa, noticias y llamada a explorar. CSS adaptable a móvil y colores consistentes en tablas y gráficos. No se inventan cifras para rellenar el diseño.

Validación: build de producción aprobado y portada HTTP 200 con logo y nuevo contenido. No se realizó validación visual automatizada en navegador ni prueba de las páginas con base conectada.

ECUAHYPE_Vista_Previa.html es una vista independiente del diseño, con CSS y logo incorporados. Se abre con doble clic y no requiere Node. Sus búsquedas y enlaces se desactivan con aviso porque es solo una vista previa.

