# Despliegue en Cloudflare Workers

Next.js 14.2.35 corre en Cloudflare Workers con `@opennextjs/cloudflare` 1.15.x (la última serie que soporta Next 14). Worker comprimido ≈ 0,8 MiB (el plan gratuito permite 3 MiB).

## Opción A — Conectar GitHub (recomendada)

1. Sube este código a https://github.com/lopezok12/ECUAHYPE (la raíz del repositorio es esta carpeta).
2. Cloudflare → **Workers & Pages → Create → Import a repository** → elige ECUAHYPE.
3. Nombre: `ecuahype`. Build command: `npx opennextjs-cloudflare build`. Deploy command: `npx opennextjs-cloudflare deploy`.
4. En **Settings → Variables and secrets** agrega: `SITE_URL`, `CONTACT_EMAIL`, `SITE_OPERATOR`, `PUBLICATION_READY=false`, y como *secretos* `VISIT_SECRET` y `CRON_SECRET` (valores aleatorios largos). Las variables `NEXT_PUBLIC_*` van también en las variables de *build*.

## Opción B — Desde tu computador

```bash
npm ci
npx wrangler login
npm run deploy
```

## Base de datos (PostgreSQL)

Sin base, el sitio se publica igual y muestra "datos pendientes". Para conectarla:

1. Crea un PostgreSQL externo (Neon o Supabase) y ejecuta `npm run db` desde tu computador con `DATABASE_URL` en `.env`.
2. Importa los CSV de SUPERCIAS desde tu computador (`npm run importar ...`), no desde Cloudflare.
3. Crea Hyperdrive:
   `npx wrangler hyperdrive create ecuahype-db --connection-string="postgres://usuario:clave@host:5432/base"`
4. Pega el `id` en `wrangler.jsonc` (línea `hyperdrive`, descoméntala) y vuelve a desplegar.

## Tareas programadas

`worker.js` ejecuta noticias (cada 30 min) y limpieza de visitas (diaria 08:00 UTC) con Cron Triggers. Necesitan el secreto `CRON_SECRET`; las noticias siguen desactivadas hasta que actives la fuente en `config/noticias.js`.

## Pendiente

- **Caché ISR:** sin R2 configurado, las páginas con `revalidate` se regeneran en cada visita. Se puede añadir caché incremental con R2 más adelante.
- Mantén `PUBLICATION_READY=false` hasta revisar contenido, textos legales y consentimiento de cookies.
