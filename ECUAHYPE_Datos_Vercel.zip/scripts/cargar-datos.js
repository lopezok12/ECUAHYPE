import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import { parse } from 'csv-parse';
import { norm } from '../lib/normalizar.js';

if (!process.env.DATABASE_URL) throw new Error('Falta DATABASE_URL en tu archivo .env. Usa la conexión de Neon; no la subas a GitHub.');
if (process.env.FUENTES_REVISADAS !== 'true') throw new Error('Configura FUENTES_REVISADAS=true en .env para habilitar la importación de las fuentes oficiales indicadas en docs/FUENTES.md.');
function ejecutar(script, args = []) {
 const r = spawnSync(process.execPath, [script, ...args], { stdio: 'inherit', env: process.env });
 if (r.error) throw r.error;
 if (r.status !== 0) throw new Error(`Falló ${script}; no se continuará con las siguientes etapas.`);
}
// Se ejecuta desde tu computador, sin exponer una ruta pública de importación.
ejecutar('scripts/descargar.js');
let ultimo = 0;
for await (const row of fs.createReadStream('data/bi_ranking.csv').pipe(parse({bom:true,columns:h=>h.map(norm),delimiter:process.env.CSV_DELIMITER||',',skip_empty_lines:true,trim:true}))) {
 const n = Number(row.anio);
 if (Number.isInteger(n) && n >= 1900 && n < new Date().getFullYear()) ultimo = Math.max(ultimo,n);
}
if (!ultimo) throw new Error('No se encontró un ejercicio fiscal cerrado válido en la fuente.');
for (const [tipo, archivo, ...args] of [['empresas','data/bi_compania.csv'],['balances','data/bi_ranking.csv',String(ultimo-1)],['balances','data/bi_ranking.csv',String(ultimo)],['ciiu','data/bi_ciiu.csv']]) {
 ejecutar('scripts/importar.js',[tipo,archivo,...args,'--dry-run']);
}
ejecutar('scripts/db.js');
ejecutar('scripts/importar.js',['empresas','data/bi_compania.csv']);
ejecutar('scripts/importar.js',['balances','data/bi_ranking.csv',String(ultimo-1)]);
ejecutar('scripts/importar.js',['balances','data/bi_ranking.csv',String(ultimo)]);
ejecutar('scripts/importar.js',['ciiu','data/bi_ciiu.csv']);
console.log(`Carga finalizada: ejercicios ${ultimo-1} y ${ultimo}. Revisa los conteos y las omisiones anteriores. Vercel debe usar la misma DATABASE_URL.`);
