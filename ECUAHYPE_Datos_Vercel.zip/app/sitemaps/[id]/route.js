import {q,hayBD} from '../../../lib/db.js';
import {siteURL,listo} from '../../../lib/site.js';
export const revalidate=86400;
async function sitemap(id){
 if(!listo||!(await hayBD()))return [];
 const filas=await q('SELECT ruc,actualizado FROM empresas ORDER BY ruc LIMIT 45000 OFFSET $1',[Number(id)*45000]);
 const extras=Number(id)===0?['','/explorar','/metodologia','/privacidad','/terminos','/contacto'].map(path=>({url:siteURL+path})):[];
 if(Number(id)===0){
  const grupos=await q(`SELECT DISTINCT actividad AS valor,'sector' AS tipo FROM empresas WHERE actividad IS NOT NULL UNION SELECT DISTINCT canton AS valor,'ciudad' AS tipo FROM empresas WHERE canton IS NOT NULL LIMIT 4500`);
  extras.push(...grupos.map(g=>({url:`${siteURL}/${g.tipo}/${encodeURIComponent(g.valor)}`})));
 }
 return [...extras,...filas.map(e=>({url:`${siteURL}/empresa/${e.ruc}`,lastModified:e.actualizado}))];
}

const escape=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
export async function GET(req,{params}) {
 if(!/^\d+\.xml$/.test(params.id)) return new Response(null,{status:404});
 const rows=await sitemap(Number(params.id.replace('.xml','')));
 if(!rows.length) return new Response(null,{status:404});
 return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${rows.map(r=>`<url><loc>${escape(r.url)}</loc>${r.lastModified?`<lastmod>${new Date(r.lastModified).toISOString()}</lastmod>`:''}</url>`).join('')}</urlset>`,{headers:{'Content-Type':'application/xml'}});
}
