import Link from "next/link";
import { q, hayBD } from "../../lib/db.js";

export const dynamic = "force-dynamic";
export const metadata = { title: "Buscar empresas", robots: {index:false,follow:true} };

export default async function Buscar({ searchParams }) {
  const t = String(searchParams?.q ?? "").trim().slice(0, 80);
  let filas = [];
  if (!(await hayBD())) return <><h1>Buscar empresas</h1><p>El buscador se habilita al conectar PostgreSQL e importar el directorio oficial.</p></>;
  if (t) {
    {
      filas = /^\d{6,13}$/.test(t)
        ? await q(`SELECT ruc, nombre, provincia FROM empresas WHERE ruc LIKE $1 || '%' ORDER BY nombre LIMIT 30`, [t])
        : await q(`SELECT ruc, nombre, provincia FROM empresas WHERE nombre ILIKE '%' || $1 || '%'
                   ORDER BY similarity(nombre, $2) DESC LIMIT 30`, [t.replace(/[%_\\]/g, "\\$&"), t]);
    }
  }
  return (
    <>
      <h1>Resultados para “{t}”</h1>
      {filas.length === 0 ? <p className="vacio">No encontramos empresas. Prueba con otra parte del nombre o con el RUC.</p> : (
        <ul className="plana">
          {filas.map((e) => (
            <li key={e.ruc}>
              <Link href={`/empresa/${e.ruc}`}>{e.nombre}</Link>
              <span className="dato">{e.provincia ?? ""} · {e.ruc}</span>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
