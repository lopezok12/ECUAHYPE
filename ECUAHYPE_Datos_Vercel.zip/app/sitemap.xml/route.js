import {q,hayBD} from '../../lib/db.js';
import {siteURL,listo} from '../../lib/site.js';
export const revalidate=86400;
const escape=s=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');
export async function GET(){
 let n=0;if(listo&&(await hayBD())){const [s]=await q('SELECT count(*)::int AS n FROM empresas');n=Math.max(1,Math.ceil(s.n/45000));}
 return new Response(`<?xml version="1.0" encoding="UTF-8"?><sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${Array.from({length:n},(_,i)=>`<sitemap><loc>${escape(siteURL)}/sitemaps/${i}.xml</loc></sitemap>`).join('')}</sitemapindex>`,{headers:{'Content-Type':'application/xml'}});
}
