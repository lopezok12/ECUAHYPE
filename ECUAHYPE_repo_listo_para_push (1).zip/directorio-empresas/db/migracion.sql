ALTER TABLE empresas ADD COLUMN IF NOT EXISTS fuente text NOT NULL DEFAULT 'SUPERCIAS';
ALTER TABLE empresas ADD COLUMN IF NOT EXISTS fuente_url text NOT NULL DEFAULT 'https://appscvsmovil.supercias.gob.ec/ranking/reporte.html';
ALTER TABLE empresas ADD COLUMN IF NOT EXISTS actualizado timestamptz NOT NULL DEFAULT now();
ALTER TABLE empresas ADD COLUMN IF NOT EXISTS ciiu text;
CREATE UNIQUE INDEX IF NOT EXISTS empresas_expediente_unique ON empresas(expediente) WHERE expediente IS NOT NULL;
ALTER TABLE balances ADD COLUMN IF NOT EXISTS fuente text NOT NULL DEFAULT 'SUPERCIAS';
ALTER TABLE balances ADD COLUMN IF NOT EXISTS fuente_url text NOT NULL DEFAULT 'https://appscvsmovil.supercias.gob.ec/ranking/reporte.html';
ALTER TABLE balances ADD COLUMN IF NOT EXISTS actualizado timestamptz NOT NULL DEFAULT now();
ALTER TABLE balances ADD COLUMN IF NOT EXISTS ciiu text;
CREATE INDEX IF NOT EXISTS empresas_canton ON empresas(canton);
CREATE INDEX IF NOT EXISTS empresas_actividad ON empresas(actividad);
CREATE TABLE IF NOT EXISTS visitas_unicas (
 ruc text NOT NULL REFERENCES empresas(ruc) ON DELETE CASCADE,
 dia date NOT NULL, visitante text NOT NULL, PRIMARY KEY(ruc,dia,visitante)
);
CREATE TABLE IF NOT EXISTS catalogo (
 id bigserial PRIMARY KEY, ruc text NOT NULL REFERENCES empresas(ruc),
 nombre text NOT NULL, descripcion text NOT NULL, enlace text,
 estado text NOT NULL DEFAULT 'pendiente' CHECK(estado IN ('pendiente','aprobado','rechazado')),
 creado timestamptz NOT NULL DEFAULT now()
);
