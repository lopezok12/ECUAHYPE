CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE IF NOT EXISTS empresas (
  ruc text PRIMARY KEY,
  expediente text,
  nombre text NOT NULL,
  tipo text,
  situacion text,
  actividad text,
  provincia text,
  canton text,
  fecha_constitucion date
);
CREATE INDEX IF NOT EXISTS empresas_nombre_trgm ON empresas USING gin (nombre gin_trgm_ops);
CREATE INDEX IF NOT EXISTS empresas_constitucion ON empresas (fecha_constitucion DESC);

CREATE TABLE IF NOT EXISTS balances (
  ruc text NOT NULL,
  anio int NOT NULL,
  ingresos numeric, gastos numeric, utilidad numeric,
  activos numeric, pasivos numeric, patrimonio numeric,
  PRIMARY KEY (ruc, anio)
);
CREATE INDEX IF NOT EXISTS balances_anio_ingresos ON balances (anio, ingresos DESC);

CREATE TABLE IF NOT EXISTS noticias (
  id serial PRIMARY KEY,
  fuente text NOT NULL,
  titulo text NOT NULL,
  resumen text,
  url text UNIQUE NOT NULL,
  publicada timestamptz
);

CREATE TABLE IF NOT EXISTS visitas (
  ruc text NOT NULL,
  dia date NOT NULL,
  conteo int NOT NULL DEFAULT 0,
  PRIMARY KEY (ruc, dia)
);
