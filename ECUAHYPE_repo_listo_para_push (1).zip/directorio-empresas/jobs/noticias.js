import {importarNoticias} from '../lib/noticias.js';
import {pool} from '../lib/db.js';
try {const r=await importarNoticias();console.log(JSON.stringify(r));if(r.some(x=>x.error)) process.exitCode=1;} finally {await pool.end();}
