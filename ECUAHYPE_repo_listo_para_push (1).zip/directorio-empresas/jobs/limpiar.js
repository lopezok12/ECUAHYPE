import {pool,q} from '../lib/db.js';
try{await q(`DELETE FROM visitas_unicas WHERE dia < current_date - 31`);}finally{await pool.end();}
