export default [
  {
    "nombre": "Banco Central del Ecuador",
    "url": "https://www.bce.fin.ec/feed/",
    "dominios": [
      "www.bce.fin.ec",
      "bce.fin.ec"
    ],
    "activa": false,
    "terminos_revisados": false,
    "permitir_extracto": false
  }
];
