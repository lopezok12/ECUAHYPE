import {usd} from '../lib/fmt.js';
export default function Grafico({datos}) {
 const serie=[...datos].sort((a,b)=>a.anio-b.anio).filter(d=>d.ingresos!=null);
 if(!serie.length) return <p>No hay ingresos disponibles para graficar.</p>;
 const min=Math.min(0,...serie.map(d=>Number(d.ingresos))),max=Math.max(1,...serie.map(d=>Number(d.ingresos)));
 const y=v=>160-(Number(v)-min)/(max-min)*130,base=y(0),paso=600/serie.length;
 return <svg className="grafico" viewBox="0 0 600 200" role="img" aria-label="Ingresos anuales en dólares"><title>Ingresos por ejercicio fiscal</title><line x1="0" x2="600" y1={base} y2={base} stroke="#7b8b9b"/>{serie.map((d,i)=><g key={d.anio}><rect x={i*paso+paso*.2} y={Math.min(y(d.ingresos),base)} width={paso*.6} height={Math.max(1,Math.abs(y(d.ingresos)-base))} fill={Number(d.ingresos)<0?'#b3261e':'#ff5a00'}><title>{d.anio}: {usd(d.ingresos)}</title></rect><text x={(i+.5)*paso} y="190" textAnchor="middle" fontSize="12">{d.anio}</text></g>)}</svg>;
}
