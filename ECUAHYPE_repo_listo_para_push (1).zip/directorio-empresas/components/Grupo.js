import Link from 'next/link';
import {notFound} from 'next/navigation';
import {q} from '../lib/db.js';
import {usd} from '../lib/fmt.js';
export default async function Grupo({tipo,valor,pagina}) {
 const columna=tipo==='sector'?'actividad':'canton';
 const page=Math.max(1,Math.min(10000,Number(pagina)||1));
 const [stats]=await q(`SELECT count(*)::int AS total FROM empresas WHERE ${columna}=$1`,[valor]);if(!stats.total) notFound();
 const [resumen]=await q(`SELECT max(b.anio) AS anio,count(b.ruc)::int AS cobertura,sum(b.ingresos) AS ingresos FROM empresas e JOIN balances b ON b.ruc=e.ruc WHERE e.${columna}=$1 AND b.anio=(SELECT max(anio) FROM balances)`,[valor]);
 const filas=await q(`SELECT ruc,nombre FROM empresas WHERE ${columna}=$1 ORDER BY nombre,ruc LIMIT 50 OFFSET $2`,[valor,(page-1)*50]);
 if(!filas.length) notFound();
 const ruta=`/${tipo}/${encodeURIComponent(valor)}`;
 return <><h1>Empresas de {valor}</h1><p>{stats.total} compañías en el directorio importado. Ejercicio {resumen.anio||'no disponible'}: {resumen.cobertura} compañías con balance. Ingresos agregados disponibles: {usd(resumen.ingresos)}.</p><p>Fuente: <a href="https://appscvsmovil.supercias.gob.ec/ranking/reporte.html">SUPERCIAS</a>. El agregado puede incluir relaciones entre compañías; no es una medida del PIB.</p><ul className="plana">{filas.map(e=><li key={e.ruc}><Link href={`/empresa/${e.ruc}`}>{e.nombre}</Link><span>{e.ruc}</span></li>)}</ul><nav>{page>1&&<Link href={`${ruta}?pagina=${page-1}`}>← Anterior </Link>}{page*50<stats.total&&<Link href={`${ruta}?pagina=${page+1}`}>Siguiente →</Link>}</nav></>;
}
