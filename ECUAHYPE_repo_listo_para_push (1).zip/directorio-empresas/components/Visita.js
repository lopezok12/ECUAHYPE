"use client";
import {useEffect} from 'react';
export default function Visita({ruc}) {
 useEffect(()=>{fetch('/api/visita',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ruc}),keepalive:true}).catch(()=>{});},[ruc]);return null;
}
