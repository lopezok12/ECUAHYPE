"use client";
import { useEffect } from "react";

// Se activa solo cuando defines NEXT_PUBLIC_ADSENSE_ID y el "slot" de cada bloque en AdSense.
export default function AdSlot({ slot, enabled }) {
  const id = process.env.NEXT_PUBLIC_ADSENSE_ID;
  useEffect(() => {
    if (!enabled || !/^ca-pub-\d{16}$/.test(id || "") || !/^\d+$/.test(slot || "")) return;
    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch {}
  }, [id, slot, enabled]);
  if (!enabled || !/^ca-pub-\d{16}$/.test(id || "") || !/^\d+$/.test(slot || "")) return null;
  return (
    <div className="anuncio"><small>Publicidad</small>
      <ins className="adsbygoogle" style={{ display: "block" }} data-ad-client={id}
        data-ad-slot={slot} data-ad-format="auto" data-full-width-responsive="true" />
    </div>
  );
}
