# Fuentes revisadas técnicamente el 1 de octubre de 2026 (UTC)

La comprobación técnica no confirma licencia de explotación comercial, legalidad de redistribución ni cumplimiento integral de la LOPDP.

## SUPERCIAS
Página oficial y diccionario: https://appscvsmovil.supercias.gob.ec/ranking/reporte.html

Descargas verificadas y leídas localmente:
- https://appscvsmovil.supercias.gob.ec/ranking/recursos/bi_compania.csv (53.735.965 bytes)
- https://appscvsmovil.supercias.gob.ec/ranking/recursos/bi_ranking.csv (373.703.646 bytes)
- https://appscvsmovil.supercias.gob.ec/ranking/recursos/bi_ciiu.csv (descargado y encabezados verificados)

Encabezados directorio: expediente,ruc,nombre,tipo,pro_codigo,provincia.
El archivo no proporciona fecha de constitución, cantón ni situación legal. Las secciones que dependen de ellos quedarán vacías hasta incorporar otra descarga oficial validada.

Balances: clave expediente + anio; RUC se resuelve contra bi_compania. Se importa ingresos_totales, total_gastos, utilidad_neta, activos y patrimonio. Se deja pasivos sin dato porque deuda_total no equivale a total_pasivos. Tampoco se reemplaza utilidad neta por utilidad_ejercicio ni ingresos totales por ingresos_ventas. Si un año antiguo no contiene estas métricas, se muestran como no disponibles.

El sitio describe actualización del CSV cada 24 horas. El ejercicio contable sigue siendo anual. Programar una revisión principal después de abril y reimportaciones posteriores para declaraciones tardías o correcciones. El portal SUPERCIAS publicó extensión del plazo de balances 2025 al 4 de mayo de 2026: no codificar 30 de abril como fecha universal e invariable.

Validación de descarga: 344.758 filas de compañías aceptables; 17 inválidas; 305 filas con RUC repetidos apartadas. Balance 2025: 154.070 filas con formatos válidos, sin duplicados por expediente/año. Esto NO significa 154.070 balances enlazados: algunos expedientes pueden faltar o estar en cuarentena en el directorio. La importación real informa las omisiones.

No redistribuimos los archivos originales dentro del ZIP. Descarga en origen y revisa términos, licencia, cobertura, taxonomía y casos ambiguos. No hemos confirmado autorización expresa para monetizar los datos. El directorio oficial identifica compañías; el importador excluye etiquetas persona natural y no importa información de administradores, socios, correos o direcciones personales. Revisar también contenido inesperado de campos de texto.

## Noticias
RSS verificado mediante descarga y lectura XML: https://www.bce.fin.ec/feed/ (Banco Central del Ecuador). Configurado pero desactivado hasta revisar términos. Las entradas se limitan a dominios oficiales y 50 por consulta; solo título y enlace por defecto. Resúmenes solo si se habilita permitir_extracto después de revisar autorización. No se descarga ni copia el cuerpo completo de la noticia.
No se confirmó RSS de SUPERCIAS, SRI, SERCOP, INEC o Ministerio de Producción. No se inventan URLs ni selectores. Sus scrapers necesitarán fixtures y comprobación de enlaces por noticia antes de activar.

## Anuncios
Revisa la política de privacidad requerida por Google: https://support.google.com/adsense/answer/1348695?hl=es
Revisa políticas de AdSense, consentimiento aplicable, CMP, tratamiento de datos y requisitos para cada región donde tengas visitantes. Las páginas legales incluidas son borradores que debes adaptar al operador y sus proveedores reales. No hay garantía de aprobación.

## Framework
Se mantuvo Next.js 14 conforme al pedido y se fijó 14.2.35, versión corregida indicada en https://nextjs.org/blog/security-update-2025-12-11 . Antes de producción verifica avisos posteriores y soporte vigente; esta comprobación no garantiza que no existan vulnerabilidades más recientes.

Next.js 14 figura como versión sin soporte en la política oficial consultada: https://nextjs.org/support-policy . Se mantuvo por requisito del proyecto; migrar a una versión con soporte antes de servir tráfico de producción.
