# Validación y límites de la entrega

- npm ci ejecutado con package-lock.json; instalación reproducible realizada.
- npm test: 3 pruebas aprobadas de números financieros, fechas reales y conservación de RUC.
- npm run build: compilación de producción aprobada en Next.js 14.2.35.
- Servidor de producción local iniciado y comprobado por HTTP: 10 rutas públicas respondieron 200 y los dos cron respondieron 401 sin secreto (resultado en http-validacion.json).
- Portada contiene contenido, metadatos noindex y modo preparación; robots bloquea indexación antes de publicación; índice sitemap responde XML.
- CSV completos descargados de SUPERCIAS y validados sin escribir en base. Validación directorio y balance 2025 en archivos JSON adjuntos.
- RSS BCE descargado, parseado y comprobado: 10 entradas con enlaces en www.bce.fin.ec. Configurado sin activar por revisión de términos pendiente.

NO verificado: SQL contra una instancia PostgreSQL real, importación real con escrituras, ficha/rankings/búsqueda con base conectada, comportamiento visual en móvil o navegador, ISR durante cambios reales de base, anuncios con cuenta aprobada o despliegue externo.

El navegador automatizado no pudo arrancar en este entorno; la descarga del navegador terminó incompleta. Se usaron pruebas HTTP para comprobar las páginas de preparación. Esto no sustituye revisión visual.

Antes de publicar necesitas configurar PostgreSQL, ejecutar npm run db, importar ambos años y CIIU, comprobar resultados con una muestra oficial, validar las rutas con datos y revisar los textos legales/las licencias. No se han realizado registro, carga de catálogo, pagos ni solicitud de AdSense. El diseño incluye CSS adaptable, pero no se declara verificación visual móvil.

Next.js 14 figura como versión sin soporte en la política oficial consultada: https://nextjs.org/support-policy . Se mantuvo por requisito del proyecto; migrar a una versión con soporte antes de servir tráfico de producción.
