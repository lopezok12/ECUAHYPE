# Logo ECUAHYPE

Logo original incorporado en public/logo-ecuahype.png, mostrado en el encabezado con proporciones conservadas y enlace a inicio. Ventana CSS oculta los márgenes transparentes; el PNG no se modifica. El título del sitio identifica ECUAHYPE.

Para actualizar tu despliegue en Vercel: reemplaza el código del repositorio conectado por el contenido de esta carpeta y guarda los cambios (commit y push). Conserva tus variables de entorno. Si la raíz de Vercel es directorio-empresas, mantén esa estructura. Vercel generará un nuevo despliegue; ábrelo cuando aparezca Ready. Esta entrega no modifica directamente tu proyecto de Vercel porque aún no se ha identificado el repositorio conectado.
