import test from 'node:test';import assert from 'node:assert/strict';
import {numero,fecha,norm,rucValido} from '../lib/normalizar.js';
test('importes oficiales, vacíos y signo',()=>{assert.equal(numero('1234567.89'),'1234567.89');assert.equal(numero('1.234,56',','),'1234.56');assert.equal(numero(''),null);assert.equal(numero('(5.25)'),'-5.25');assert.throws(()=>numero('1,23'));assert.throws(()=>numero('abc'));});
test('fechas calendario reales',()=>{assert.equal(fecha('29/02/2024'),'2024-02-29');assert.throws(()=>fecha('31/02/2025'));assert.throws(()=>fecha('2025-13-01'));});
test('RUC conserva cero y encabezados',()=>{assert.equal(norm(' Razón Social '),'razon_social');assert.ok(rucValido('0991234567001'));assert.ok(!rucValido('991234567001'));});
