import {siteURL,listo} from '../lib/site.js';
export default function robots(){return {rules:[{userAgent:'*',allow:listo?'/':undefined,disallow:listo?['/api/','/buscar']:['/']}],sitemap:listo?`${siteURL}/sitemap.xml`:undefined};}
