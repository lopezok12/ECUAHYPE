import Link from 'next/link';
import {q} from '../../lib/db.js';
export const revalidate=86400;
export const metadata={title:'Explorar por sector y ciudad'};
export default async function Explorar(){
 if(!process.env.DATABASE_URL) return <><h1>Explorar empresas</h1><p>El directorio aún no está conectado.</p></>;
 const [sectores,ciudades]=await Promise.all([q(`SELECT actividad AS nombre,count(*)::int AS total FROM empresas WHERE actividad IS NOT NULL GROUP BY actividad ORDER BY total DESC LIMIT 100`),q(`SELECT canton AS nombre,count(*)::int AS total FROM empresas WHERE canton IS NOT NULL GROUP BY canton ORDER BY total DESC LIMIT 100`)]);
 return <><h1>Un mapa del tejido empresarial</h1><p>Compañías registradas en el conjunto importado. No representa a todos los negocios del Ecuador.</p><div className="rejilla">{[['Sectores','sector',sectores],['Ciudades','ciudad',ciudades]].map(([titulo,tipo,filas])=><section className="panel" key={tipo}><h2>{titulo}</h2>{filas.length?filas.map(f=><p key={f.nombre}><Link href={`/${tipo}/${encodeURIComponent(f.nombre)}`}>{f.nombre}</Link> · {f.total} compañías</p>):<p>Esta fuente no contiene este dato. Se requiere enriquecer el directorio oficial.</p>}</section>)}</div></>;
}
