import {q} from '../../../../lib/db.js';
export const dynamic='force-dynamic';
export async function GET(req){
 if(!process.env.CRON_SECRET||req.headers.get('authorization')!==`Bearer ${process.env.CRON_SECRET}`)return new Response(null,{status:401});
 await q('DELETE FROM visitas_unicas WHERE dia < current_date - 31');return Response.json({ok:true});
}
