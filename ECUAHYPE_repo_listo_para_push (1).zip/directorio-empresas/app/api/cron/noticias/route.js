import {importarNoticias} from '../../../../lib/noticias.js';
export const dynamic='force-dynamic';
export async function GET(req) {
 if(!process.env.CRON_SECRET||req.headers.get('authorization')!==`Bearer ${process.env.CRON_SECRET}`) return Response.json({error:'No autorizado'},{status:401});
 const resultados=await importarNoticias();return Response.json({resultados},{status:resultados.some(r=>r.error)?502:200});
}
