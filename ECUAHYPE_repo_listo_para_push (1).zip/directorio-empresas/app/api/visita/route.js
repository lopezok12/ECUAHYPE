import {createHmac,randomUUID} from 'node:crypto';
import {cookies} from 'next/headers';
import {q} from '../../../lib/db.js';
export async function POST(req) {
 if(!process.env.VISIT_SECRET) return new Response(null,{status:503});
 if(req.headers.get('origin')!==new URL(req.url).origin) return new Response(null,{status:403});
 if(/bot|crawler|spider/i.test(req.headers.get('user-agent')||'')) return new Response(null,{status:204});
 try {
  const {ruc}=await req.json();if(typeof ruc!=='string'||!/^\d{13}$/.test(ruc)) return new Response(null,{status:400});
  const c=cookies(),raw=c.get('visitor')?.value,token=raw&&/^[a-f0-9-]{36}$/.test(raw)?raw:randomUUID();
  const visitante=createHmac('sha256',process.env.VISIT_SECRET).update(token).digest('hex');
  await q(`WITH nueva AS (INSERT INTO visitas_unicas(ruc,dia,visitante) SELECT ruc,(now() AT TIME ZONE 'America/Guayaquil')::date,$2 FROM empresas WHERE ruc=$1 ON CONFLICT DO NOTHING RETURNING ruc,dia)
   INSERT INTO visitas(ruc,dia,conteo) SELECT ruc,dia,1 FROM nueva ON CONFLICT(ruc,dia) DO UPDATE SET conteo=visitas.conteo+1`,[ruc,visitante]);
  c.set('visitor',token,{httpOnly:true,sameSite:'lax',secure:new URL(req.url).protocol==='https:',maxAge:86400*30,path:'/'});
  return new Response(null,{status:204});
 } catch {return new Response(null,{status:503});}
}
