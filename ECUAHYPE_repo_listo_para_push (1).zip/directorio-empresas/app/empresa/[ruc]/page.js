import { notFound } from "next/navigation";
import { q } from "../../../lib/db.js";
import { usd } from "../../../lib/fmt.js";
import Grafico from "../../../components/Grafico.js";
import AdSlot from "../../../components/AdSlot.js";
import {siteURL, fuenteURL} from "../../../lib/site.js";
import Visita from "../../../components/Visita.js";

// Páginas generadas bajo demanda y guardadas en caché 24 h (sirve rápido y es bueno para SEO).
export const revalidate = 86400;
export async function generateStaticParams() { return []; }

async function cargar(ruc) {
  if (!/^\d{13}$/.test(ruc)) return null;
  {
    const [e] = await q(`SELECT ruc, nombre, tipo, situacion, actividad, provincia, canton,
                         to_char(fecha_constitucion,'DD/MM/YYYY') AS fecha, fuente_url, actualizado FROM empresas WHERE ruc = $1`, [ruc]);
    if (!e) return null;
    const balances = await q(`SELECT anio, ingresos::float8 AS ingresos, gastos::float8 AS gastos,
                              utilidad::float8 AS utilidad, activos::float8 AS activos, patrimonio::float8 AS patrimonio
                               , fuente_url, actualizado FROM balances WHERE ruc = $1 ORDER BY anio DESC`, [ruc]);
    return { e, balances };
  }
}

export async function generateMetadata({ params }) {
  const d = await cargar(params.ruc);
  if (!d) return { title: "Empresa no encontrada" };
  return {
    title: `${d.e.nombre}: ingresos y utilidades`,
    alternates: {canonical: `/empresa/${d.e.ruc}`},
    description: `Ingresos, gastos y utilidad de ${d.e.nombre} (RUC ${d.e.ruc})${d.e.provincia ? ", " + d.e.provincia : ""}, según la Superintendencia de Compañías.`,
  };
}

export default async function Empresa({ params }) {
  const d = await cargar(params.ruc);
  if (!d) notFound();
  const { e, balances } = d;
  return (
    <>
      <Visita ruc={e.ruc} />
      <h1>{e.nombre}</h1>
      <dl>
        <dt>RUC</dt><dd>{e.ruc}</dd>
        <dt>Actividad</dt><dd>{e.actividad ?? "—"}</dd>
        <dt>Ubicación</dt><dd>{[e.canton, e.provincia].filter(Boolean).join(", ") || "—"}</dd>
        <dt>Constitución</dt><dd>{e.fecha ?? "—"}</dd>
        <dt>Situación legal</dt><dd>{e.situacion ?? "—"}</dd>
      </dl>

      <h2>Estados financieros anuales</h2><p>Fuente: <a href={e.fuente_url || fuenteURL}>SUPERCIAS</a> · Directorio cargado: {new Date(e.actualizado).toLocaleDateString('es-EC',{timeZone:'America/Guayaquil'})}. “—” significa dato no disponible; no equivale a cero.</p>
      <script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify({'@context':'https://schema.org','@type':'Organization',name:e.nombre,taxID:e.ruc,url:`${siteURL}/empresa/${e.ruc}`}).replace(/</g,'\\u003c')}}/>
      {balances.length>1 && balances[0].anio===balances[1].anio+1 && Number(balances[1].ingresos)>0 && balances[0].ingresos!=null && <p>Los ingresos de {balances[0].anio} variaron {((Number(balances[0].ingresos)/Number(balances[1].ingresos)-1)*100).toFixed(1)} % respecto a {balances[1].anio}.</p>}
      {balances.length === 0 ? <p className="vacio">Esta empresa aún no tiene balances cargados.</p> : (
        <>
          <Grafico datos={balances} />
          <div className="tabla">
            <table>
              <thead><tr><th>Año</th><th>Ingresos</th><th>Gastos</th><th>Utilidad</th><th>Activos</th><th>Patrimonio</th><th>Fuente / carga</th></tr></thead>
              <tbody>
                {balances.map((b) => (
                  <tr key={b.anio}>
                    <td>{b.anio}</td><td>{usd(b.ingresos)}</td><td>{usd(b.gastos)}</td>
                    <td className={b.utilidad < 0 ? "baja" : ""}>{usd(b.utilidad)}</td>
                    <td>{usd(b.activos)}</td><td>{usd(b.patrimonio)}</td><td><a href={b.fuente_url}>SUPERCIAS</a> · {new Date(b.actualizado).toLocaleDateString("es-EC")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
      <AdSlot enabled={process.env.PUBLICATION_READY === "true" && process.env.ADSENSE_ENABLED === "true"} slot={process.env.NEXT_PUBLIC_AD_SLOT_EMPRESA} />
    </>
  );
}
