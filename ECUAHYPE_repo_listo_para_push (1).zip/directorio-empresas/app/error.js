"use client";
export default function Error({reset}) {return <section className="panel"><h1>Los datos no están disponibles</h1><p>Hay un problema al consultar la base de datos. Esto no significa que la empresa no exista.</p><button onClick={reset}>Volver a intentar</button></section>;}
