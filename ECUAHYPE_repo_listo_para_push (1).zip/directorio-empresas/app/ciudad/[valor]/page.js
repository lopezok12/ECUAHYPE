import Grupo from '../../../components/Grupo.js';
export const revalidate=86400;
export async function generateStaticParams() {return [];}
export function generateMetadata({params,searchParams}){return {title:`Empresas de ${params.valor}`,alternates:{canonical:`/ciudad/${encodeURIComponent(params.valor)}`},robots:{index:!searchParams?.pagina,follow:true}};}
export default function Page({params,searchParams}){return <Grupo tipo="ciudad" valor={params.valor} pagina={searchParams?.pagina}/>;}
