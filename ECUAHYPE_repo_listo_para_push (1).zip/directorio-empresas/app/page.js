import Link from "next/link";
import Portada from "../components/Portada.js";
import { q } from "../lib/db.js";
import { usd, pct } from "../lib/fmt.js";
import AdSlot from "../components/AdSlot.js";

export const revalidate = 300;

const seguro = q;
const ANIO = "(SELECT MAX(anio) FROM balances)";

function Seccion({ titulo, filas, dato, claseDato }) {
  return (
    <section className="panel">
      <div className="panel-cabecera"><span className="eyebrow">RESULTADOS ANUALES</span><span className="flecha-panel" aria-hidden="true">↗</span></div><h2>{titulo}</h2>
      {filas.length === 0 ? <p className="vacio">Aún no hay datos.</p> : (
        <ol>
          {filas.map((e) => (
            <li key={e.ruc}>
              <Link href={`/empresa/${e.ruc}`}>{e.nombre}</Link>
              <span className={`dato ${claseDato?.(e) ?? ""}`}>{dato(e)}</span>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}

export default async function Inicio() {
  if (!process.env.DATABASE_URL) return <><Portada/><div className="rejilla">{[["01","Empresas nuevas","Las compañías que empiezan a construir su historia."],["02","Mayores por ingresos","Una visión de las compañías con mayores ingresos reportados."],["03","Mayores caídas de ingresos","Cambios entre ejercicios fiscales consecutivos."],["04","Empresas con pérdidas","Resultados anuales, con contexto y fuente visible."]].map(([numero,titulo,descripcion])=><section className="panel panel-vacio" key={titulo}><div className="panel-cabecera"><span className="numero-panel">{numero}</span><span className="flecha-panel" aria-hidden="true">↗</span></div><h2>{titulo}</h2><p>{descripcion}</p><div className="estado-datos"><span/> Datos pendientes de cargar</div></section>)}</div><section className="noticias panel"><div><p className="eyebrow">DESDE LA FUENTE</p><h2>La actualidad, con respaldo.</h2><p>Noticias y comunicados de instituciones oficiales.</p></div><Link className="boton boton-secundario" href="/metodologia">Ver fuentes oficiales ↗</Link></section><section className="cta"><p className="eyebrow">UNA PERSPECTIVA MÁS COMPLETA</p><h2>Conoce más. Decide mejor.</h2><p>Compara resultados y explora el tejido empresarial ecuatoriano.</p><Link className="boton" href="/explorar">Explorar empresas ↗</Link></section></>;
  const [nuevas, populares, mayores, caidas, perdidas, noticias, periodos] = await Promise.all([
    seguro(`SELECT ruc, nombre, to_char(fecha_constitucion,'DD/MM/YYYY') AS fecha FROM empresas
            WHERE fecha_constitucion IS NOT NULL AND fecha_constitucion <= current_date ORDER BY fecha_constitucion DESC LIMIT 10`),
    seguro(`SELECT e.ruc, e.nombre, SUM(v.conteo)::int AS vistas FROM visitas v JOIN empresas e ON e.ruc = v.ruc
            WHERE v.dia > current_date - 30 GROUP BY e.ruc, e.nombre ORDER BY vistas DESC LIMIT 10`),
    seguro(`SELECT e.ruc, e.nombre, b.ingresos::float8 AS ingresos FROM balances b JOIN empresas e ON e.ruc = b.ruc
            WHERE b.anio = ${ANIO} AND b.ingresos IS NOT NULL ORDER BY b.ingresos DESC LIMIT 10`),
    seguro(`SELECT e.ruc, e.nombre, (b.ingresos - p.ingresos)::float8 AS caida,
                   ((b.ingresos - p.ingresos) / p.ingresos)::float8 AS variacion
            FROM balances b JOIN balances p ON p.ruc = b.ruc AND p.anio = b.anio - 1
            JOIN empresas e ON e.ruc = b.ruc
            WHERE b.anio = ${ANIO} AND p.ingresos > 0 AND b.ingresos < p.ingresos
            ORDER BY (b.ingresos - p.ingresos) ASC LIMIT 10`),
    seguro(`SELECT e.ruc, e.nombre, b.utilidad::float8 AS utilidad FROM balances b JOIN empresas e ON e.ruc = b.ruc
            WHERE b.anio = ${ANIO} AND b.utilidad < 0 ORDER BY b.utilidad ASC LIMIT 10`),
    seguro(`SELECT fuente, titulo, resumen, url, to_char(publicada,'DD/MM/YYYY') AS fecha FROM noticias
            ORDER BY publicada DESC NULLS LAST LIMIT 8`),
    seguro(`SELECT MAX(anio) AS anio FROM balances`),
  ]);

  const hayVisitas = populares.length > 0;
  return (
    <>
      <Portada/>
      <p className="aviso">Ejercicio fiscal: {periodos[0]?.anio ?? "sin balances"} · Fuente: <a href="https://appscvsmovil.supercias.gob.ec/ranking/reporte.html">SUPERCIAS</a>. Caídas en USD frente al año anterior; solo compañías con ambos años disponibles.</p><div className="rejilla">
        <Seccion titulo="Empresas nuevas" filas={nuevas} dato={(e) => e.fecha} />
        {hayVisitas
          ? <Seccion titulo="Más visitadas este mes" filas={populares} dato={(e) => `${e.vistas} visitas`} />
          : <Seccion titulo="Mayores por ingresos" filas={mayores} dato={(e) => usd(e.ingresos)} />}
        <Seccion titulo="Mayores caídas de ingresos" filas={caidas}
          dato={(e) => `${usd(e.caida)} (${pct(e.variacion)})`} claseDato={() => "baja"} />
        <Seccion titulo="Empresas con pérdidas" filas={perdidas}
          dato={(e) => usd(e.utilidad)} claseDato={() => "baja"} />
      </div>

      <AdSlot enabled={process.env.PUBLICATION_READY === "true" && process.env.ADSENSE_ENABLED === "true"} slot={process.env.NEXT_PUBLIC_AD_SLOT_HOME} />

      <section className="panel">
        <h2>Noticias oficiales</h2>
        {noticias.length === 0 ? <p className="vacio">Aún no hay noticias cargadas.</p> : (
          <ul className="plana">
            {noticias.map((n) => (
              <li key={n.url}>
                <a href={n.url} target="_blank" rel="noopener noreferrer">{n.titulo}</a>{n.resumen && <p>{n.resumen}</p>}
                <span className="dato">{n.fuente} · {n.fecha ?? ""}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
