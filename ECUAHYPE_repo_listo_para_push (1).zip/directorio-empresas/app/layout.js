import './globals.css';
import Link from 'next/link';
import Image from 'next/image';
import Script from 'next/script';
import {siteURL,listo} from '../lib/site.js';
export const metadata={metadataBase:new URL(siteURL),title:{default:'ECUAHYPE | Empresas del Ecuador',template:'%s | ECUAHYPE'},description:'Explora compañías ecuatorianas, estados financieros anuales y rankings con fuentes públicas.',robots:{index:listo,follow:listo}};
export default function Layout({children}) {
 const ads=process.env.ADSENSE_ENABLED==='true'&&listo&&/^ca-pub-\d{16}$/.test(process.env.NEXT_PUBLIC_ADSENSE_ID||'')?process.env.NEXT_PUBLIC_ADSENSE_ID:null;
 return <html lang="es-EC"><body><a className="salto" href="#contenido">Saltar al contenido</a><header className="top"><Link href="/" className="marca marca-logo" aria-label="ECUAHYPE — Inicio"><span className="logo-ventana"><Image src="/logo-ecuahype.png" alt="ECUAHYPE" width={1024} height={1024} priority className="logo-imagen" /></span></Link><nav aria-label="Principal"><Link href="/explorar">Explorar</Link><Link href="/metodologia">Fuentes y método</Link><Link href="/catalogo">Catálogo</Link></nav><form action="/buscar"><input name="q" placeholder="Nombre o RUC" aria-label="Buscar empresa" required maxLength={80}/><button>Buscar</button></form></header><main id="contenido">{!listo&&<p className="aviso">Versión de preparación · Datos pendientes de revisión antes de publicar.</p>}{children}</main><footer><p>Portal independiente. Fuente principal: Superintendencia de Compañías, Valores y Seguros. Los estados financieros son anuales; la fecha de carga no es el año fiscal.</p><nav><Link href="/privacidad">Privacidad</Link> · <Link href="/terminos">Términos</Link> · <Link href="/contacto">Contacto y correcciones</Link></nav></footer>{ads&&<Script id="adsense" strategy="afterInteractive" src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ads}`} crossOrigin="anonymous"/>}</body></html>;
}
