# Empresas del Ecuador — versión preparada

Portal en español: Next.js 14.2.35, App Router, JavaScript, PostgreSQL y SVG. Código completo. No necesita WebSockets. No se ha desplegado ni conectado a una base de producción.

## 1. Requisitos e instalación

Node.js 20.9 o superior, PostgreSQL con permiso para crear extensión pg_trgm. Descomprime el ZIP y abre terminal dentro de `directorio-empresas`:

```bash
npm ci
cp .env.example .env
```

En Windows puedes copiar `.env.example` a `.env` desde el explorador. Ajusta DATABASE_URL con la conexión de tu PostgreSQL. No compartas contraseñas ni las incluyas en Git. Usa las opciones SSL del proveedor con verificación de certificados; no desactives esa verificación.

```bash
npm run db
```

Si tu proveedor tiene un editor SQL, pega primero schema.sql y después migracion.sql. Para una base existente revisa respaldo, duplicados por expediente y migración antes de ejecutar: los importadores no resuelven identidades ambiguas históricas.

## 2. Archivos oficiales y revisión

```bash
npm run descargar
npm run inspeccionar -- data/bi_compania.csv
npm run inspeccionar -- data/bi_ranking.csv
```

Los enlaces y encabezados reales se documentan en docs/FUENTES.md. Las URLs pueden cambiar. Los originales no van en este ZIP; el script los descarga. Si un archivo viene en Excel, exporta CSV conservando RUC como texto, con UTF-8, coma separadora y punto decimal. CSV_DELIMITER, CSV_DECIMAL y CSV_ENCODING permiten ajustar formatos; no se adivinan. No rellena RUC incompletos ni crea datos faltantes.

Revisa los términos y licencias de SUPERCIAS para el uso comercial previsto. Después de revisarlos, configura FUENTES_REVISADAS=true. No equivale a una autorización legal automática.

```bash
npm run importar -- empresas data/bi_compania.csv --dry-run
npm run importar -- balances data/bi_ranking.csv 2025 --dry-run
npm run importar -- empresas data/bi_compania.csv
npm run importar -- balances data/bi_ranking.csv 2024
npm run importar -- balances data/bi_ranking.csv 2025
npm run importar -- ciiu data/bi_ciiu.csv
```

La importación se ejecuta en transacción: un error revierte esa ejecución. Usa lotes y enlaza balances por expediente. Todos los RUC duplicados y todos los balances ambiguos se separan, con identificadores en el resumen; no se elige una versión arbitraria. Si ya existen esos RUC en una base anterior, revisa y retira o corrige esos registros antes de publicar; no basta con omitirlos en la nueva importación. No elimina automáticamente compañías ausentes de una nueva descarga. La situación legal necesita una fuente específica; no se deduce por ausencia del ranking.

El directorio descargado no contiene constitución, ciudad ni situación legal. Por eso Empresas nuevas y páginas de ciudad requieren enriquecimiento oficial posterior; no rellenar con provincia ni fecha de carga. La actividad sí se enriquece con CIIU a partir del último balance disponible. El catálogo se muestra como próxima etapa.

## 3. Ejecutar y comprobar

```bash
npm test
npm run build
npm run start
```

Abre http://localhost:3000 . Para editar durante desarrollo: `npm run dev`. Sin DATABASE_URL la portada muestra preparación explícita, sin números simulados. Un error real de base se muestra como datos no disponibles.

Con datos reales verifica buscador por nombre y RUC, fichas, rankings, comparación 2025/2024 y exactitud con muestra oficial. Las pruebas incluidas comprueban números y fechas, y se validó el formato de los CSV descargados; revisa docs/VALIDACION.md para el alcance exacto de las verificaciones.

## 4. Noticias y cron

En `config/noticias.js` hay un RSS real del BCE, desactivado. Tras revisar términos configura `activa: true` y `terminos_revisados: true`. Por defecto no guarda extractos. Configura otras fuentes solo con URLs y permisos comprobados.

```bash
npm run noticias
```

En VPS cron (ajusta rutas; sin .env en Git):

```cron
*/30 * * * * cd /ruta/directorio-empresas && npm run noticias >> /ruta/noticias.log 2>&1
0 3 * * * cd /ruta/directorio-empresas && node --env-file=.env jobs/limpiar.js >> /ruta/limpieza.log 2>&1
```

La limpieza borra identificadores de más de 31 días. Programa directorio semanal y balances después del cierre anual, con revisión posterior de correcciones. Para automatizar importación primero valida el archivo, conserva copia y comprueba conteos; no ejecutar una importación de archivo nuevo sin supervisión de cambios de formato.

`vercel.json` incluye noticias diarias y limpieza diaria protegidas por CRON_SECRET. Vercel Hobby permite una ejecución diaria por cron; para noticias cada 30 minutos usa cron en VPS o un plan compatible. Documentación: https://vercel.com/docs/cron-jobs/usage-and-pricing . Para 30 minutos cambia schedule a `*/30 * * * *` solo si tu plan permite esa frecuencia y duración; verifica condiciones actuales en Vercel. Los CSV grandes se importan fuera de una función serverless. No hay autoimportación de balances en Vercel.

## 5. Despliegue

### Vercel

Sube el código a un repositorio, importa ese repositorio en Vercel y selecciona esta carpeta como raíz. Framework Next.js, instalación `npm ci`, build `npm run build`. Usa PostgreSQL persistente externo con conexión apta para serverless/pooling. Configura variables desde .env.example: DATABASE_URL, SITE_URL con URL real, CONTACT_EMAIL, SITE_OPERATOR, VISIT_SECRET aleatorio de al menos 32 bytes y CRON_SECRET aleatorio. No necesitas poner FUENTES_REVISADAS en Vercel si importas fuera de allí. Ejecuta ambos SQL e importación antes del despliegue con datos.

PUBLICATION_READY=false mantiene noindex y anuncios apagados durante preparación; no equivale a acceso privado. Si necesitas privacidad, activa protección de despliegue en Vercel. Comprueba variables, dominio y todas las rutas antes de cambiar PUBLICATION_READY=true.

### VPS + Cloudflare

Ejecuta Node y PostgreSQL, `npm ci`, `npm run build`, `npm run start` con un supervisor de procesos. Añade proxy HTTPS (Nginx/Caddy) y Cloudflare delante si deseas. No guardes caché de /api ni /buscar en Cloudflare. ISR de Next funciona en el servidor; varias réplicas requieren caché compartida. Incluido output standalone; si usas ese artefacto, copia también .next/static y public cuando exista. Haz copias de base y configura cron.

## 6. SEO y AdSense

Hay metadata por empresa, canonical, JSON-LD Organization con RUC, páginas de sector y ciudad, robots y sitemap index `/sitemap.xml` que enlaza segmentos de 45.000 compañías. Búsqueda noindex. Al publicar comprueba sitemap y envío a Search Console. No indexar fichas vacías o con valor insuficiente: revisar cobertura, añadir comparaciones útiles y contenido propio antes de indexar masivamente. No usar texto automático idéntico como único valor de miles de páginas.

Antes de AdSense adapta Privacidad, Contacto y Términos, declara el operador, revisa protección de datos, cookies, CMP y permisos de fuentes. No hay consentimiento implementado: integrar una CMP certificada cuando sea requerida antes de activar anuncios. La visita propia usa cookie y HMAC (dato seudónimo), no registra IP en tablas de visitas; configura limpieza y revisa logs del hosting. Su deduplicación reduce repetición, no evita manipulación sofisticada; añade rate limiting compartido antes de depender comercialmente del ranking de visitas.

Cuando corresponda configura ADSENSE_ENABLED=true, NEXT_PUBLIC_ADSENSE_ID y slots. Las variables NEXT_PUBLIC requieren reconstruir. PUBLICATION_READY también debe ser true. `/ads.txt` se genera del identificador. Los anuncios no están aprobados ni activados en esta entrega.

## 7. Etapa comercial posterior

La tabla catalogo prepara productos moderados, pero NO hay registro ni API pública para subir productos, pagos o propiedad verificada. Antes de habilitar: autenticación, verificación de vinculación empresarial, panel propietario, moderación, prevención de suplantación, tratamiento de contactos, imágenes seguras y cobros. Los planes destacados deben identificarse como publicidad y mantenerse fuera de rankings financieros. No se presenta esta etapa como funcional.

## Qué debes ajustar personalmente

- Hosting, base de datos, dominio y variables reales.
- Permiso/licencia comercial de cada fuente y revisión jurídica de borradores legales.
- Duplicados oficiales y cobertura del directorio; completar constitución/cantón/situación con fuente validada.
- Revisar exactitud de muestra oficial y conteos después de importación.
- Habilitar RSS revisados, cron apropiado al plan y limpieza de identificadores.
- CMP/consentimiento cuando aplique, rate limiting y solicitud propia de AdSense.
- Avisos de seguridad vigentes y soporte de Next 14 antes de producción.

Next.js 14 figura como versión sin soporte en la política oficial consultada: https://nextjs.org/support-policy . Se mantuvo por requisito del proyecto; migrar a una versión con soporte antes de servir tráfico de producción.
