import fs from 'node:fs';
import {parse} from 'csv-parse';
import {norm} from '../lib/normalizar.js';
const archivo=process.argv[2]; if(!archivo) throw new Error('Uso: npm run inspeccionar -- archivo.csv');
const lector=fs.createReadStream(archivo).pipe(parse({bom:true,columns:h=>h.map(norm),delimiter:process.env.CSV_DELIMITER||',',to:3}));
for await(const fila of lector) console.log(JSON.stringify(fila,null,2));
