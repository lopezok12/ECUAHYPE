import fs from 'node:fs';
import {Readable} from 'node:stream';
import {pipeline} from 'node:stream/promises';
fs.mkdirSync('data',{recursive:true});
for(const nombre of ['bi_compania.csv','bi_ranking.csv','bi_ciiu.csv']) {
 const url=`https://appscvsmovil.supercias.gob.ec/ranking/recursos/${nombre}`;
 const res=await fetch(url,{signal:AbortSignal.timeout(300000)});
 if(!res.ok) throw new Error(`${nombre}: HTTP ${res.status}`);
 await pipeline(Readable.fromWeb(res.body),fs.createWriteStream(`data/${nombre}.tmp`));
 fs.renameSync(`data/${nombre}.tmp`,`data/${nombre}`); console.log(`Descargado ${nombre}. Verifica encabezados y términos antes de importar.`);
}
