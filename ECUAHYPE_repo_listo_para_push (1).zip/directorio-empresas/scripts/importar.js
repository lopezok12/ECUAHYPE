import fs from 'node:fs';
import {parse} from 'csv-parse';
import {pool} from '../lib/db.js';
import {norm,numero,fecha,pick,rucValido} from '../lib/normalizar.js';
const [tipo,archivo,anioArg,...flags]=process.argv.slice(2);
const dry=process.argv.includes('--dry-run');
if(!['empresas','balances','ciiu'].includes(tipo)||!archivo) throw new Error('Uso: importar empresas|balances|ciiu archivo.csv [año] [--dry-run]');
if(!dry && process.env.FUENTES_REVISADAS!=='true') throw new Error('Revisa términos y licencias y configura FUENTES_REVISADAS=true antes de escribir datos.');
const opciones={bom:true,columns:h=>h.map(norm),delimiter:process.env.CSV_DELIMITER||',',skip_empty_lines:true,trim:true};
// Primera pasada: separar todos los identificadores ambiguos, sin elegir una versión arbitraria.
const frecuencias=new Map();
if(tipo!=='ciiu') {
 const previo=fs.createReadStream(archivo,{encoding:process.env.CSV_ENCODING||'utf8'}).pipe(parse(opciones));
 for await(const row of previo) {
  if(tipo==='balances' && anioArg && anioArg!=='--dry-run' && Number(row.anio)!==Number(anioArg)) continue;
  const key=tipo==='empresas'?pick(row,'ruc'):`${row.expediente}:${row.anio}`;
  frecuencias.set(key,(frecuencias.get(key)||0)+1);
 }
}
const ambiguas=[...frecuencias.entries()].filter(([,n])=>n>1).map(([k])=>k);
const cliente=dry?null:await pool.connect();
let total=0,omitidas=0,duplicadas=0; const expedientes=new Map();
if(cliente) { await cliente.query('BEGIN'); await cliente.query("SET LOCAL statement_timeout = '60s'"); }
const lector=fs.createReadStream(archivo,{encoding:process.env.CSV_ENCODING||'utf8'}).pipe(parse({bom:true,columns:h=>h.map(norm),delimiter:process.env.CSV_DELIMITER||',',skip_empty_lines:true,trim:true}));
try {
 if(tipo==='balances' && cliente) for(const e of (await cliente.query('SELECT ruc,expediente FROM empresas WHERE expediente IS NOT NULL')).rows) expedientes.set(e.expediente,e.ruc);
 let headersChecked=false;
 let lote=[];
 async function volcar() {
  if(!lote.length||!cliente) {lote=[];return;}
  if(tipo==='empresas') {
   await cliente.query(`INSERT INTO empresas(ruc,expediente,nombre,tipo,provincia,canton,actividad,situacion,fecha_constitucion)
    SELECT ruc,expediente,nombre,tipo,provincia,canton,actividad,situacion,fecha_constitucion::date FROM jsonb_to_recordset($1::jsonb) AS x(ruc text,expediente text,nombre text,tipo text,provincia text,canton text,actividad text,situacion text,fecha_constitucion text)
    ON CONFLICT(ruc) DO UPDATE SET nombre=excluded.nombre,tipo=excluded.tipo,expediente=excluded.expediente,provincia=excluded.provincia,canton=coalesce(excluded.canton,empresas.canton),actividad=coalesce(excluded.actividad,empresas.actividad),situacion=coalesce(excluded.situacion,empresas.situacion),fecha_constitucion=coalesce(excluded.fecha_constitucion,empresas.fecha_constitucion),actualizado=now()`,[JSON.stringify(lote)]);
  } else if(tipo==='balances') {
   await cliente.query(`INSERT INTO balances(ruc,anio,ingresos,gastos,utilidad,activos,patrimonio,ciiu)
    SELECT ruc,anio,ingresos::numeric,gastos::numeric,utilidad::numeric,activos::numeric,patrimonio::numeric,ciiu FROM jsonb_to_recordset($1::jsonb) AS x(ruc text,anio int,ingresos text,gastos text,utilidad text,activos text,patrimonio text,ciiu text)
    ON CONFLICT(ruc,anio) DO UPDATE SET ingresos=excluded.ingresos,gastos=excluded.gastos,utilidad=excluded.utilidad,activos=excluded.activos,patrimonio=excluded.patrimonio,ciiu=excluded.ciiu,actualizado=now()`,[JSON.stringify(lote)]);
  }
  lote=[];
 }
 
 for await(const row of lector) {
  if(!headersChecked) {
   const required=tipo==='empresas'?['ruc','nombre','tipo']:tipo==='ciiu'?['ciiu','descripcion']:['expediente','anio','ingresos_totales','utilidad_neta','total_gastos','activos','patrimonio'];
   if(required.some(k=>!(k in row))) throw new Error(`Faltan columnas: ${required.filter(k=>!(k in row)).join(', ')}. Usa inspeccionar; no se importó nada.`);
   headersChecked=true;
  }
  if(tipo==='ciiu') {
   if(cliente) await cliente.query(`UPDATE empresas e SET actividad=$1,ciiu=$2 FROM balances b WHERE b.ruc=e.ruc AND b.ciiu=$2 AND b.anio=(SELECT max(anio) FROM balances WHERE ruc=e.ruc)`,[row.descripcion,row.ciiu]);total++;continue;
  }
  let ruc=pick(row,'ruc');
  if(tipo==='balances') {
   const anio=Number(row.anio);
   if(!Number.isInteger(anio)||anio<1900||anio>new Date().getFullYear()) throw new Error('Año inválido');
   if(anioArg && anioArg!=='--dry-run' && anio!==Number(anioArg)) continue;
   ruc=expedientes.get(pick(row,'expediente'));
   if(!ruc && !dry) {omitidas++;continue;}
   const key=`${row.expediente}:${anio}`; if(frecuencias.get(key)>1) {duplicadas++;continue;}
   lote.push({ruc,anio,ingresos:numero(row.ingresos_totales,process.env.CSV_DECIMAL),gastos:numero(row.total_gastos,process.env.CSV_DECIMAL),utilidad:numero(row.utilidad_neta,process.env.CSV_DECIMAL),activos:numero(row.activos,process.env.CSV_DECIMAL),patrimonio:numero(row.patrimonio,process.env.CSV_DECIMAL),ciiu:pick(row,'ciiu_n6')});
  } else {
   if(!rucValido(ruc)||!pick(row,'nombre')||!pick(row,'tipo') || /persona natural/i.test(row.tipo)) {omitidas++;continue;}
   if(frecuencias.get(ruc)>1) {duplicadas++;continue;}
   lote.push({ruc,expediente:pick(row,'expediente'),nombre:pick(row,'nombre'),tipo:pick(row,'tipo'),provincia:pick(row,'provincia'),canton:pick(row,'canton'),actividad:pick(row,'actividad'),situacion:pick(row,'situacion_legal','situacion'),fecha_constitucion:fecha(pick(row,'fecha_constitucion'))});
  }
  total++; if(lote.length>=500) await volcar();
 }
 if(!headersChecked) throw new Error('CSV vacío');
 await volcar(); if(cliente) await cliente.query('COMMIT');
 console.log(JSON.stringify({modo:dry?'validación sin escribir':'importación',total,omitidas,duplicadas,identificadores_ambiguos:ambiguas}));
} catch(e) {if(cliente) await cliente.query('ROLLBACK');throw e;}
finally {cliente?.release();await pool.end();}
