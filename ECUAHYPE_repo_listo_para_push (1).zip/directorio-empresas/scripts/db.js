import fs from 'node:fs';
import {pool} from '../lib/db.js';
if(!process.env.DATABASE_URL)throw new Error('Configura DATABASE_URL en .env');
const c=await pool.connect();
try {await c.query('BEGIN');for(const path of ['db/schema.sql','db/migracion.sql'])await c.query(fs.readFileSync(path,'utf8'));await c.query('COMMIT');console.log('Esquema preparado.');}
catch(e){await c.query('ROLLBACK');throw e;}
finally{c.release();await pool.end();}
